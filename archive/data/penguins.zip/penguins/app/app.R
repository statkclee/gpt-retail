library(shiny)
library(tidyverse)
library(ggplot2)
library(plotly)
library(DT)
library(viridis)
library(shinythemes)

penguins <- read_csv("../data/penguins.csv")

theme_penguin <- theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    axis.title = element_text(size = 10),
    legend.position = "bottom"
  )

ui <- fluidPage(
  theme = shinytheme("flatly"),
  
  tags$head(
    tags$style(HTML("
      .main-header { 
        background-color: #2c3e50; 
        color: white; 
        padding: 20px; 
        text-align: center;
        margin-bottom: 20px;
      }
      .section-header {
        background-color: #ecf0f1;
        padding: 10px;
        margin: 10px 0;
        border-radius: 5px;
      }
      .key-metric {
        background-color: #3498db;
        color: white;
        padding: 15px;
        text-align: center;
        border-radius: 5px;
        margin: 10px;
      }
      .warning-box {
        background-color: #e74c3c;
        color: white;
        padding: 15px;
        border-radius: 5px;
        margin: 10px 0;
      }
    "))
  ),
  
  div(class = "main-header",
    h1("🐧 펭귄 보호를 위한 데이터 분석 대시보드"),
    h3("기후위기 속 남극 펭귄의 생존 현황")
  ),
  
  fluidRow(
    column(3,
      div(class = "key-metric",
        h4("총 관측 개체수"),
        h2(nrow(penguins))
      )
    ),
    column(3,
      div(class = "key-metric",
        h4("관측된 종"),
        h2(n_distinct(penguins$species))
      )
    ),
    column(3,
      div(class = "key-metric",
        h4("서식 섬"),
        h2(n_distinct(penguins$island))
      )
    ),
    column(3,
      div(class = "key-metric",
        h4("관측 기간"),
        h2(paste(min(penguins$year), "-", max(penguins$year)))
      )
    )
  ),
  
  hr(),
  
  tabsetPanel(
    tabPanel("종 분포 현황",
      fluidRow(
        column(6,
          div(class = "section-header", h4("섬별 펭귄 종 분포")),
          plotlyOutput("distribution_plot", height = "400px")
        ),
        column(6,
          div(class = "section-header", h4("종별 개체수 비율")),
          plotlyOutput("species_pie", height = "400px")
        )
      ),
      hr(),
      fluidRow(
        column(12,
          div(class = "section-header", h4("상세 분포 데이터")),
          DTOutput("distribution_table")
        )
      )
    ),
    
    tabPanel("기후변화 영향",
      fluidRow(
        column(12,
          div(class = "warning-box",
            h4("⚠️ 주요 위험 지표"),
            p("체중 감소와 개체수 변화는 기후변화로 인한 먹이 부족의 신호일 수 있습니다.")
          )
        )
      ),
      fluidRow(
        column(6,
          div(class = "section-header", h4("연도별 개체수 변화")),
          plotlyOutput("yearly_trend", height = "400px")
        ),
        column(6,
          div(class = "section-header", h4("연도별 평균 체중 변화")),
          plotlyOutput("mass_trend", height = "400px")
        )
      ),
      hr(),
      fluidRow(
        column(12,
          div(class = "section-header", h4("종별 체중 변화 추세")),
          verbatimTextOutput("mass_analysis")
        )
      )
    ),
    
    tabPanel("형태학적 특성",
      fluidRow(
        column(4,
          div(class = "section-header", h4("분석할 특성 선택")),
          selectInput("morph_var", "측정 항목:",
            choices = c(
              "부리 길이" = "bill_length_mm",
              "부리 깊이" = "bill_depth_mm",
              "날개 길이" = "flipper_length_mm",
              "체중" = "body_mass_g"
            )
          ),
          checkboxInput("show_sex", "성별로 구분", value = TRUE)
        ),
        column(8,
          plotlyOutput("morphology_plot", height = "500px")
        )
      ),
      hr(),
      fluidRow(
        column(6,
          div(class = "section-header", h4("체중 vs 날개 길이")),
          plotlyOutput("scatter_plot", height = "400px")
        ),
        column(6,
          div(class = "section-header", h4("종별 성비")),
          plotlyOutput("sex_ratio", height = "400px")
        )
      )
    ),
    
    tabPanel("보호 전략",
      fluidRow(
        column(12,
          div(class = "section-header", 
            h3("펭귄 보호를 위한 데이터 기반 제언")
          ),
          
          div(style = "padding: 20px;",
            h4("1. 종별 위험도 평가"),
            tableOutput("risk_assessment"),
            
            br(),
            
            h4("2. 주요 발견사항"),
            tags$ul(
              tags$li("Chinstrap 펭귄은 단일 섬(Dream)에만 서식하여 가장 취약한 상태입니다."),
              tags$li("전반적인 체중 감소 추세는 먹이 부족을 시사합니다."),
              tags$li("성비 불균형은 번식 성공률에 영향을 미칠 수 있습니다.")
            ),
            
            br(),
            
            h4("3. 보호 전략 제안"),
            tags$ol(
              tags$li("서식지가 제한적인 Chinstrap 펭귄에 대한 집중 모니터링"),
              tags$li("기후변화에 따른 먹이 서식지 변화 추적"),
              tags$li("번식지 보호구역 확대"),
              tags$li("국제 협력을 통한 남극 생태계 보전")
            )
          )
        )
      )
    ),
    
    tabPanel("원시 데이터",
      fluidRow(
        column(12,
          div(class = "section-header", h4("펭귄 관측 데이터")),
          DTOutput("raw_data")
        )
      )
    )
  )
)

server <- function(input, output, session) {
  
  output$distribution_plot <- renderPlotly({
    p <- penguins %>%
      count(species, island) %>%
      ggplot(aes(x = island, y = n, fill = species)) +
      geom_col(position = "dodge") +
      scale_fill_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
      labs(x = "섬", y = "개체수", fill = "종") +
      theme_penguin
    
    ggplotly(p)
  })
  
  output$species_pie <- renderPlotly({
    species_count <- penguins %>%
      count(species) %>%
      mutate(percentage = n / sum(n) * 100)
    
    plot_ly(species_count, 
            labels = ~species, 
            values = ~n,
            type = 'pie',
            textposition = 'inside',
            textinfo = 'label+percent',
            marker = list(colors = viridis(3, option = "plasma")))
  })
  
  output$distribution_table <- renderDT({
    penguins %>%
      group_by(island, species) %>%
      summarise(개체수 = n(), .groups = 'drop') %>%
      pivot_wider(names_from = species, values_from = 개체수, values_fill = 0) %>%
      datatable(options = list(pageLength = 10))
  })
  
  output$yearly_trend <- renderPlotly({
    p <- penguins %>%
      group_by(year, species) %>%
      summarise(count = n(), .groups = 'drop') %>%
      ggplot(aes(x = year, y = count, color = species)) +
      geom_line(size = 1.2) +
      geom_point(size = 3) +
      scale_color_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
      scale_x_continuous(breaks = 2007:2009) +
      labs(x = "연도", y = "관측 개체수", color = "종") +
      theme_penguin
    
    ggplotly(p)
  })
  
  output$mass_trend <- renderPlotly({
    p <- penguins %>%
      group_by(species, year) %>%
      summarise(avg_mass = mean(body_mass_g, na.rm = TRUE), .groups = 'drop') %>%
      ggplot(aes(x = year, y = avg_mass, fill = species)) +
      geom_col(position = "dodge") +
      scale_fill_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
      scale_x_continuous(breaks = 2007:2009) +
      labs(x = "연도", y = "평균 체중 (g)", fill = "종") +
      theme_penguin
    
    ggplotly(p)
  })
  
  output$mass_analysis <- renderPrint({
    mass_change <- penguins %>%
      group_by(species) %>%
      summarise(
        `2007년 평균` = mean(body_mass_g[year == 2007], na.rm = TRUE),
        `2009년 평균` = mean(body_mass_g[year == 2009], na.rm = TRUE),
        .groups = 'drop'
      ) %>%
      mutate(
        `변화량(g)` = `2009년 평균` - `2007년 평균`,
        `변화율(%)` = round(`변화량(g)` / `2007년 평균` * 100, 2)
      )
    
    print(mass_change)
  })
  
  output$morphology_plot <- renderPlotly({
    var_name <- switch(input$morph_var,
      "bill_length_mm" = "부리 길이 (mm)",
      "bill_depth_mm" = "부리 깊이 (mm)",
      "flipper_length_mm" = "날개 길이 (mm)",
      "body_mass_g" = "체중 (g)"
    )
    
    if(input$show_sex) {
      p <- penguins %>%
        filter(!is.na(sex)) %>%
        ggplot(aes_string(x = "species", y = input$morph_var, fill = "sex")) +
        geom_violin(alpha = 0.7) +
        scale_fill_manual(values = c("female" = "#FF6B6B", "male" = "#4ECDC4"),
                          labels = c("female" = "암컷", "male" = "수컷"))
    } else {
      p <- penguins %>%
        ggplot(aes_string(x = "species", y = input$morph_var, fill = "species")) +
        geom_violin(alpha = 0.7) +
        scale_fill_viridis_d(option = "plasma", begin = 0.2, end = 0.8)
    }
    
    p <- p + 
      labs(x = "종", y = var_name) +
      theme_penguin
    
    ggplotly(p)
  })
  
  output$scatter_plot <- renderPlotly({
    p <- penguins %>%
      filter(!is.na(sex)) %>%
      ggplot(aes(x = flipper_length_mm, y = body_mass_g, color = species)) +
      geom_point(alpha = 0.6) +
      scale_color_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
      labs(x = "날개 길이 (mm)", y = "체중 (g)", color = "종") +
      theme_penguin
    
    ggplotly(p)
  })
  
  output$sex_ratio <- renderPlotly({
    p <- penguins %>%
      filter(!is.na(sex)) %>%
      count(species, sex) %>%
      group_by(species) %>%
      mutate(prop = n / sum(n)) %>%
      ggplot(aes(x = species, y = prop, fill = sex)) +
      geom_col() +
      scale_fill_manual(values = c("female" = "#FF6B6B", "male" = "#4ECDC4"),
                        labels = c("female" = "암컷", "male" = "수컷")) +
      scale_y_continuous(labels = scales::percent) +
      labs(x = "종", y = "비율", fill = "성별") +
      theme_penguin
    
    ggplotly(p)
  })
  
  output$risk_assessment <- renderTable({
    penguins %>%
      group_by(species) %>%
      summarise(
        `총 개체수` = n(),
        `서식 섬 수` = n_distinct(island),
        .groups = 'drop'
      ) %>%
      mutate(
        `위험도` = case_when(
          `서식 섬 수` == 1 ~ "매우 높음",
          `서식 섬 수` == 2 ~ "중간",
          TRUE ~ "낮음"
        )
      )
  })
  
  output$raw_data <- renderDT({
    datatable(penguins, 
              options = list(
                pageLength = 25,
                scrollX = TRUE
              ))
  })
}

shinyApp(ui = ui, server = server)