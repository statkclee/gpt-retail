library(tidyverse)
library(ggplot2)
library(patchwork)
library(viridis)

penguins <- read_csv("data/penguins.csv")

theme_penguin <- theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5),
    axis.title = element_text(size = 10),
    legend.position = "bottom"
  )

p1 <- penguins %>%
  count(species, island) %>%
  ggplot(aes(x = island, y = n, fill = species)) +
  geom_col(position = "dodge") +
  scale_fill_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
  labs(
    title = "펭귄 종의 서식지 분포",
    subtitle = "섬별 펭귄 종 개체수",
    x = "섬", y = "개체수", fill = "종"
  ) +
  theme_penguin +
  geom_text(aes(label = n), position = position_dodge(0.9), vjust = -0.5, size = 3)

p2 <- penguins %>%
  group_by(year, species) %>%
  summarise(count = n(), .groups = 'drop') %>%
  ggplot(aes(x = year, y = count, color = species)) +
  geom_line(size = 1.2) +
  geom_point(size = 3) +
  scale_color_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
  scale_x_continuous(breaks = 2007:2009) +
  labs(
    title = "연도별 펭귄 개체수 변화",
    subtitle = "기후변화의 영향 모니터링",
    x = "연도", y = "관측 개체수", color = "종"
  ) +
  theme_penguin

p3 <- penguins %>%
  group_by(species, year) %>%
  summarise(avg_mass = mean(body_mass_g, na.rm = TRUE), .groups = 'drop') %>%
  ggplot(aes(x = year, y = avg_mass, fill = species)) +
  geom_col(position = "dodge") +
  scale_fill_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
  scale_x_continuous(breaks = 2007:2009) +
  scale_y_continuous(labels = scales::comma) +
  labs(
    title = "연도별 평균 체중 변화",
    subtitle = "먹이 가용성 지표",
    x = "연도", y = "평균 체중 (g)", fill = "종"
  ) +
  theme_penguin

p4 <- penguins %>%
  filter(!is.na(sex)) %>%
  ggplot(aes(x = flipper_length_mm, y = body_mass_g, color = species)) +
  geom_point(alpha = 0.6, size = 2) +
  geom_smooth(method = "lm", se = TRUE, alpha = 0.2) +
  scale_color_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
  facet_wrap(~sex, labeller = labeller(sex = c(male = "수컷", female = "암컷"))) +
  labs(
    title = "체중과 날개 길이의 관계",
    subtitle = "성별에 따른 형태학적 특성",
    x = "날개 길이 (mm)", y = "체중 (g)", color = "종"
  ) +
  theme_penguin

p5 <- penguins %>%
  ggplot(aes(x = species, y = bill_length_mm, fill = species)) +
  geom_violin(alpha = 0.7) +
  geom_boxplot(width = 0.3, alpha = 0.8) +
  scale_fill_viridis_d(option = "plasma", begin = 0.2, end = 0.8) +
  labs(
    title = "종별 부리 길이 분포",
    subtitle = "먹이 적응 특성",
    x = "종", y = "부리 길이 (mm)"
  ) +
  theme_penguin +
  theme(legend.position = "none")

p6 <- penguins %>%
  filter(!is.na(sex)) %>%
  count(species, sex) %>%
  group_by(species) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = species, y = prop, fill = sex)) +
  geom_col() +
  scale_fill_manual(values = c("female" = "#FF6B6B", "male" = "#4ECDC4"),
                    labels = c("female" = "암컷", "male" = "수컷")) +
  scale_y_continuous(labels = scales::percent) +
  labs(
    title = "종별 성비",
    subtitle = "번식 가능성 지표",
    x = "종", y = "비율", fill = "성별"
  ) +
  theme_penguin +
  geom_hline(yintercept = 0.5, linetype = "dashed", alpha = 0.5)

ggsave("R/plot_distribution.png", p1, width = 10, height = 6, dpi = 300)
ggsave("R/plot_yearly_trend.png", p2, width = 10, height = 6, dpi = 300)
ggsave("R/plot_mass_change.png", p3, width = 10, height = 6, dpi = 300)
ggsave("R/plot_morphology.png", p4, width = 12, height = 6, dpi = 300)
ggsave("R/plot_bill_distribution.png", p5, width = 8, height = 6, dpi = 300)
ggsave("R/plot_sex_ratio.png", p6, width = 8, height = 6, dpi = 300)

combined_plot <- (p1 + p2) / (p3 + p6)
ggsave("R/combined_dashboard.png", combined_plot, width = 16, height = 12, dpi = 300)

cat("시각화 완료! 다음 파일들이 생성되었습니다:\n")
cat("- R/plot_distribution.png\n")
cat("- R/plot_yearly_trend.png\n")
cat("- R/plot_mass_change.png\n")
cat("- R/plot_morphology.png\n")
cat("- R/plot_bill_distribution.png\n")
cat("- R/plot_sex_ratio.png\n")
cat("- R/combined_dashboard.png\n")