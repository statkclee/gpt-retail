library(tidyverse)
library(broom)

penguins <- read_csv("data/penguins.csv")

cat("=== 기후위기가 펭귄에 미치는 영향 분석 ===\n\n")

island_year_trend <- penguins %>%
  group_by(island, year) %>%
  summarise(
    total_count = n(),
    avg_body_mass = mean(body_mass_g, na.rm = TRUE),
    avg_bill_length = mean(bill_length_mm, na.rm = TRUE),
    .groups = 'drop'
  )

cat("1. 섬별 연도별 개체수 변화\n")
island_trends <- island_year_trend %>%
  group_by(island) %>%
  nest() %>%
  mutate(
    model = map(data, ~ lm(total_count ~ year, data = .x)),
    tidied = map(model, tidy)
  ) %>%
  unnest(tidied) %>%
  filter(term == "year") %>%
  select(island, estimate, p.value) %>%
  mutate(
    trend = ifelse(estimate > 0, "증가", "감소"),
    significant = ifelse(p.value < 0.05, "유의함", "유의하지 않음")
  )

print(island_trends)
cat("\n")

body_mass_trends <- penguins %>%
  group_by(species, year) %>%
  summarise(
    avg_body_mass = mean(body_mass_g, na.rm = TRUE),
    sd_body_mass = sd(body_mass_g, na.rm = TRUE),
    n = n(),
    .groups = 'drop'
  )

cat("2. 종별 체중 변화 추세 (기후변화로 인한 먹이 부족 지표)\n")
species_mass_trends <- penguins %>%
  group_by(species) %>%
  nest() %>%
  mutate(
    model = map(data, ~ lm(body_mass_g ~ year, data = .x)),
    tidied = map(model, tidy)
  ) %>%
  unnest(tidied) %>%
  filter(term == "year") %>%
  select(species, estimate, p.value) %>%
  mutate(
    yearly_change_g = estimate,
    trend = ifelse(estimate > 0, "증가", "감소"),
    significant = ifelse(p.value < 0.05, "유의함", "유의하지 않음")
  )

print(species_mass_trends)
cat("\n")

morphology_changes <- penguins %>%
  group_by(species, year) %>%
  summarise(
    avg_bill_length = mean(bill_length_mm, na.rm = TRUE),
    avg_bill_depth = mean(bill_depth_mm, na.rm = TRUE),
    avg_flipper_length = mean(flipper_length_mm, na.rm = TRUE),
    .groups = 'drop'
  )

cat("3. 형태학적 변화 (적응 지표)\n")
bill_trends <- penguins %>%
  group_by(species) %>%
  nest() %>%
  mutate(
    bill_length_model = map(data, ~ lm(bill_length_mm ~ year, data = .x)),
    flipper_model = map(data, ~ lm(flipper_length_mm ~ year, data = .x))
  ) %>%
  mutate(
    bill_trend = map(bill_length_model, ~ tidy(.x) %>% filter(term == "year")),
    flipper_trend = map(flipper_model, ~ tidy(.x) %>% filter(term == "year"))
  ) %>%
  select(species, bill_trend, flipper_trend) %>%
  unnest(cols = c(bill_trend, flipper_trend), names_sep = "_") %>%
  select(species, 
         bill_change = bill_trend_estimate, 
         bill_p = bill_trend_p.value,
         flipper_change = flipper_trend_estimate,
         flipper_p = flipper_trend_p.value)

print(bill_trends)
cat("\n")

population_risk <- penguins %>%
  group_by(species) %>%
  summarise(
    total_observed = n(),
    years_observed = n_distinct(year),
    islands_inhabited = n_distinct(island),
    .groups = 'drop'
  ) %>%
  mutate(
    habitat_diversity = islands_inhabited / 3,
    risk_level = case_when(
      habitat_diversity <= 0.33 ~ "높음 (서식지 제한적)",
      habitat_diversity <= 0.66 ~ "중간",
      TRUE ~ "낮음 (서식지 다양)"
    )
  )

cat("4. 종별 멸종 위험도 평가\n")
print(population_risk)
cat("\n")

early_late_comparison <- penguins %>%
  mutate(period = ifelse(year <= 2008, "early", "late")) %>%
  group_by(species, period) %>%
  summarise(
    avg_body_mass = mean(body_mass_g, na.rm = TRUE),
    avg_bill_length = mean(bill_length_mm, na.rm = TRUE),
    count = n(),
    .groups = 'drop'
  ) %>%
  pivot_wider(names_from = period, values_from = c(avg_body_mass, avg_bill_length, count)) %>%
  mutate(
    mass_change_pct = (avg_body_mass_late - avg_body_mass_early) / avg_body_mass_early * 100,
    count_change_pct = (count_late - count_early) / count_early * 100
  )

cat("5. 초기 vs 후기 비교\n")
print(early_late_comparison)

cat("\n\n=== 주요 발견사항 ===\n")
cat("- 체중 감소 추세가 관찰되면 먹이 부족을 의미할 수 있음\n")
cat("- 서식지가 제한적인 종일수록 기후변화에 취약함\n")
cat("- 형태학적 변화는 환경 적응의 신호일 수 있음\n")