library(tidyverse)
library(ggplot2)
library(scales)

penguins <- read_csv("data/penguins.csv")

penguins <- penguins %>%
  mutate(species = factor(species),
         island = factor(island),
         sex = factor(sex))

cat("=== 펭귄 보호를 위한 기초 데이터 분석 ===\n\n")

cat("1. 데이터 개요\n")
cat("총 관측 수:", nrow(penguins), "\n")
cat("관측 기간:", min(penguins$year, na.rm = TRUE), "-", max(penguins$year, na.rm = TRUE), "\n\n")

species_summary <- penguins %>%
  group_by(species) %>%
  summarise(
    count = n(),
    proportion = n() / nrow(penguins),
    avg_body_mass = mean(body_mass_g, na.rm = TRUE),
    avg_flipper_length = mean(flipper_length_mm, na.rm = TRUE)
  )

cat("2. 종별 분포\n")
print(species_summary)
cat("\n")

island_species <- penguins %>%
  group_by(island, species) %>%
  summarise(count = n(), .groups = 'drop') %>%
  pivot_wider(names_from = species, values_from = count, values_fill = 0)

cat("3. 섬별 종 분포\n")
print(island_species)
cat("\n")

yearly_trend <- penguins %>%
  group_by(year, species) %>%
  summarise(count = n(), .groups = 'drop')

cat("4. 연도별 개체수 변화\n")
print(yearly_trend)
cat("\n")

body_changes <- penguins %>%
  group_by(year, species) %>%
  summarise(
    avg_body_mass = mean(body_mass_g, na.rm = TRUE),
    sd_body_mass = sd(body_mass_g, na.rm = TRUE),
    .groups = 'drop'
  )

cat("5. 연도별 평균 체중 변화 (기후변화 지표)\n")
print(body_changes)
cat("\n")

sex_ratio <- penguins %>%
  filter(!is.na(sex)) %>%
  group_by(species, sex) %>%
  summarise(count = n(), .groups = 'drop') %>%
  pivot_wider(names_from = sex, values_from = count) %>%
  mutate(ratio = male / female)

cat("6. 종별 성비\n")
print(sex_ratio)
cat("\n")

missing_data <- penguins %>%
  summarise_all(~sum(is.na(.))) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "missing_count") %>%
  mutate(missing_pct = missing_count / nrow(penguins) * 100)

cat("7. 결측치 현황\n")
print(missing_data)