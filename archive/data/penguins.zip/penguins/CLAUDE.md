# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a penguin conservation data analysis project focused on understanding the impact of climate change on Antarctic penguin populations. The project analyzes the Palmer Penguins dataset to identify extinction risks and develop data-driven conservation strategies.

## Project Structure

```
penguins/
├── data/
│   └── penguins.csv       # Palmer penguins dataset
├── scripts/
│   ├── penguin_eda.R      # Basic exploratory data analysis
│   ├── climate_impact_analysis.R  # Climate change impact analysis
│   └── visualizations.R   # ggplot2 visualization generation
├── app/
│   └── app.R             # Shiny single-page application dashboard
├── R/                    # Generated visualization outputs
└── README.md            # Project documentation
```

## Data Structure

The main dataset is located at `data/penguins.csv` and contains measurements of penguins with the following columns:
- `rowid`: Unique identifier
- `species`: Penguin species (Adelie, Chinstrap, Gentoo)
- `island`: Island location (Biscoe, Dream, Torgersen)
- `bill_length_mm`: Bill length in millimeters
- `bill_depth_mm`: Bill depth in millimeters
- `flipper_length_mm`: Flipper length in millimeters
- `body_mass_g`: Body mass in grams
- `sex`: Penguin sex (male/female)
- `year`: Year of observation (2007-2009)

## Development Commands

### Running Analysis Scripts
```r
# Basic EDA
source("scripts/penguin_eda.R")

# Climate impact analysis
source("scripts/climate_impact_analysis.R")

# Generate visualizations
source("scripts/visualizations.R")

# Launch Shiny dashboard
shiny::runApp("app/app.R")
```

### Required R Packages
```r
install.packages(c(
  "tidyverse", "ggplot2", "plotly", "shiny", "shinythemes",
  "DT", "viridis", "patchwork", "broom", "scales"
))
```

## Key Analysis Focus Areas

1. **Species Distribution**: Analyzing penguin populations across different islands
2. **Climate Impact Indicators**: 
   - Body mass changes over time (food availability indicator)
   - Population trends by year and location
   - Morphological adaptations
3. **Conservation Risk Assessment**: Identifying species with limited habitats
4. **Sex Ratio Analysis**: Monitoring breeding potential

## Architecture Notes

- **R Scripts**: Modular analysis scripts focusing on specific aspects (EDA, climate impact, visualization)
- **Shiny App**: Interactive single-page application with multiple tabs for different analysis views
- **Visualization**: Using ggplot2 with viridis color scheme for accessibility and plotly for interactivity

## Permissions

Claude has permission to use `ls`, `find`, and `mkdir` commands via Bash as configured in `.claude/settings.local.json`.