# Korean Typst Extension

한글 과학 보고서 작성을 위한 Quarto Typst Extension입니다.

## 기능

- 한글 폰트 자동 설정 (Noto Sans KR 우선)
- 제목, 저자, 날짜를 변수로 처리하여 한글 폰트 적용
- 한글 문서에 적합한 제목 스타일링
- 표 및 목차 한글 폰트 적용
- 과학 보고서에 최적화된 레이아웃

## 사용 방법

### 1. 기본 사용법 (단순한 한글 설정만 적용)

```typst
// Korean Typst Extension 사용
#import "_extensions/korean-typst/typst-template.typ": *

// 한글 설정 적용
#show: apply-korean-setup
```

### 2. 고급 사용법 (제목 페이지를 변수로 처리)

```typst
// Korean Typst Extension 사용
#import "_extensions/korean-typst/typst-template.typ": *

// 한글 문서 템플릿 적용 (제목, 저자, 날짜를 변수로 처리)
#show: korean-doc.with(
  title: "문서 제목",
  author: "작성자 이름", 
  date: "2025-07-21",
  title-size: 26pt,           // 제목 크기
  title-color: "#1f4e79",     // 제목 색상
  title-weight: "bold",       // 제목 굵기
  author-size: 16pt,          // 저자명 크기
  author-color: "#444444",    // 저자명 색상
  date-size: 14pt,            // 날짜 크기
  date-color: "#666666"       // 날짜 색상
)
```

### 3. YAML 헤더 설정

```yaml
---
title: "문서 제목"
author: "작성자"
date: today
format:
  typst:
    toc: true
    toc-depth: 2
    number-sections: true
    fontsize: 11pt
    margin:
      x: 2.5cm
      y: 3cm
    papersize: a4
lang: ko-KR
---
```

## 포함된 폰트

- NotoSansKR-Regular.ttf
- NotoSansKR-Medium.ttf  
- NotoSansKR-Bold.ttf

## 스타일 설정

- **제목 색상**: 파란색 계열 (#2c5aa0)
- **제목 크기**: 
  - Level 1: 20pt
  - Level 2: 17pt
  - Level 3: 15pt
- **표 스타일**: 회색 테두리, 헤더 배경색
- **본문 폰트**: 11pt, 양쪽 정렬

## 디렉토리 구조

```
_extensions/korean-typst/
├── _extension.yml          # Extension 설정
├── typst-template.typ      # Typst 템플릿
├── korean-typst.lua        # Lua 필터
├── README.md              # 사용법
├── NotoSansKR-Regular.ttf # 폰트 파일
├── NotoSansKR-Medium.ttf  # 폰트 파일
└── NotoSansKR-Bold.ttf    # 폰트 파일
```