-- Korean Typst Filter
-- 한글 Typst 필터

function Meta(meta)
  -- 한글 폰트 설정을 메타데이터에 추가
  if meta.lang and pandoc.utils.stringify(meta.lang) == "ko-KR" then
    -- 기본 한글 폰트 설정
    if not meta.font then
      meta.font = {"Noto Sans KR", "Apple SD Gothic Neo", "Helvetica", "Arial"}
    end
    
    if not meta["heading-family"] then
      meta["heading-family"] = {"Noto Sans KR", "Apple SD Gothic Neo", "Helvetica", "Arial"}
    end
  end
  
  return meta
end

return {
  { Meta = Meta }
}